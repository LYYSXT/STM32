#ifndef __SERIAL_H
#define __SERIAL_H
#include "sys.h"
#include <stdio.h>
#include <stdarg.h>

extern int key1,key2,key3,key4,key5;

void Serial_Init(void);
void Serial_SendByte(uint8_t Byte);
void Serial_SendArray(uint8_t *Array, uint16_t Length);
void Serial_SendString(char *String);
void Serial_SendNumber(uint32_t Number, uint8_t Length);
void Serial_Printf(char *format, ...);

uint8_t Serial_GetRxFlag(void);
uint8_t Serial_GetRxData(void);


//���ֻ������	GUI
void get_slave_data(uint8_t data);
void lanya_receive(void);
uint8_t checksum(void);
void Int_to_Byte(int i,uint8_t *byte);
void Float_to_Byte(float f,uint8_t *byte);
void Short_to_Byte(short s,uint8_t *byte);
void lanya_transmit(void); 

#endif


//	delay_init();
//	OLED_Init();
//	OLED_ColorTurn(0);//0������ʾ��1 ��ɫ��ʾ
//	OLED_DisplayTurn(0);//0������ʾ 1 ��Ļ��ת��ʾ
//	OLED_Clear();
//	Serial_Init();
////	test_0();		//��������
//	uint8_t Direction;

//	while(1)
//	{	
//		lanya_transmit();
//		
//		if(key_1==0)
//		{
//			test_number++;
//			if(test_number==80)
//			{
//				key_1=1;
//			}			
//		}
//		else if(key_1==1)
//		{
//			test_number--;
//			if(test_number==10)
//			{
//				key_1=0;
//			}	
//		}
//		
//		OLED_ShowNum(16,16,key2,1,16,1);
//		OLED_Refresh();
//		
//	
//		if (Serial_GetRxFlag() == 1)		//�ж��Ƿ��յ�����
//		{
//			Direction = Serial_GetRxData();		//��ȡ����
//			OLED_ShowChar(0,0,Direction,16,1);
//			OLED_Refresh();
//			Serial_SendByte(Direction);		//�����ݻش�������
//		}
//		
//	}
